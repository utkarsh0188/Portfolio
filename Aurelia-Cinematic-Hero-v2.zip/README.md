# Aurelia — Luxury Hotel Demo

Premium portfolio demo website for a fictional luxury hotel brand.

## Run
Open `index.html` in a browser, or upload the folder to a GitHub Pages repository.

## Notes
- Responsive single-page site
- Pure HTML/CSS/JS
- Google Fonts
- Unsplash imagery
- Smooth reveal interactions
- Reservation form demo
